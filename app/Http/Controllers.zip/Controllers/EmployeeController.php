<?php

namespace App\Http\Controllers;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\success_status_code;
use function App\Helpers\bad_response_status_code;
use App\Employee;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
class EmployeeController extends Controller
{
    public function index()
    {
        $employees = Employee::all();      
        $data['employees']  =  $employees;

        return view('employees', $data);
    }

    public function create(Request $request)
    {
        $id = Auth::user()->company_id;  

        $input = $request->all();

            try{
    
                $input['company_id'] = $id;

                $employee = Employee::create($input);
    
                $success['employee'] = $employee;
    
                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $employee
                );

                return Redirect()->route('employee_home')->with('success', 'Employee Created Successfully !');

            } 
    
            catch (\Exception $exception) {
            // DB::rollback();
    
            return api_request_response(
                "error",
                $exception->getMessage(),
                bad_response_status_code()
            );


        }           
    }

}
