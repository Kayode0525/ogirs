<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Invoice;
use App\Company;
use App\MonthlyReturns;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class InvoiceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $data['company_name'] = Auth::user()->name;
        $data['invoices']=Invoice::where('company_id',Auth::user()->company_id)->get();

        return view('company.invoice',$data);
    }

    public function invoice(Request $request)
    {
      //  dd($request->id);

       $data['invoice'] =$invoice =Invoice::where('id',$request->id)->firstOrFail();

      // dd($invoice);

       $data['company']= $company =Company::where('id',$invoice->company_id)->firstOrFail();

        return view('company.invoice_details',$data);
    }

    public function make_payment_now(Request $request)
    {

        Session::put("company_id", 11);

        return Redirect::route("pay");

    }

    public function show_invoice(Request $request)
    {

        $data["dataID"] = $dataID = Session::get('DataID');
        $data["records"] =$records=MonthlyReturns::where('upload_id',$dataID)->get();


        return view('invoice', $data);

    }

    public function debtors_list()
    {

        $debtors = Invoice::all();
        
        $data["debtors"] = $debtors;

        return view('admin.debtors_list',$data);
 
    }
    public function payment()
    {

        $debtors = Invoice::all();
        $data["debtors"] = $debtors;

        return view('admin.payment',$data);
 
    }
}
