<?php

namespace App\Http\Controllers;

use function App\Helpers\api_request_response;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\generate_uuid;
use function App\Helpers\success_status_code;
use App\Imports\MonthlyReturnsImport;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Input;
use App\Models\TaxAgent;
use App\MonthlyReturns;
use Illuminate\Support\Facades\Session;
use File;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Excel;

class ExcelUploadController extends Controller
{

    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        return view('fileuploads');
    }


    /**
     * Works fine for maatwebsite/excel version 2.1.0
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
   

    public function importMonthlyReturns(Request $request) {

       // dd("here");
       set_time_limit(0);

       $uid=generate_uuid();
       Session::put('DataID',$uid);

        \Excel::import(new MonthlyReturnsImport, request()->file('filess')->store('temp'));

       // return Redirect::back()->with('success',"Record successfully uploaded !.");

       return Redirect::route("show_invoice");//->with('success',"Record successfully uploaded !.");

    }

}
